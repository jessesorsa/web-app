<script>
    import Hero from "../components/Hero.svelte";
    import Card from "../components/Card.svelte";
    import Menu from "../components/Menu.svelte";
</script>

<svelte:head>
    <title>My application</title>
</svelte:head>

<div class="flex relative">
    <div class="flex-1 relative">
        <Hero link="/service" />
    </div>

    <div class="flex-1 absolute top-0 left-0">
        <Menu />
    </div>
</div>

<div class="flex justify-evenly mt-10 mb-10">
    <Card
        title="Solar platform"
        description="For streamlining your next solar energy project with our intelligent data platform."
        link="/service"
    />
    <Card title="Contact" description="Get in touch" link="/contact" />
</div>
