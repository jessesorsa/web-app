<script>
    import ServiceText from "../../components/Service-text.svelte";
</script>

<ServiceText />
