<div class="drawer lg:drawer-open">
    <input id="my-drawer-2" type="checkbox" class="drawer-toggle" />
    <div class="drawer-content justify-center">
        <!-- Page content here -->
        <label for="my-drawer-2" class="btn btn-primary drawer-button lg:hidden"
            >Menu</label
        >
    </div>
    <div class="drawer-side">
        <label
            for="my-drawer-2"
            aria-label="close sidebar"
            class="drawer-overlay"
        ></label>
        <ul class="menu p-4 w-40 min-h-full bg-base-200 text-base-content">
            <!-- Sidebar content here -->
            <li><a href="/service">Pricing </a></li>
            <li><a href="/service">Our vision </a></li>
        </ul>
    </div>
</div>
