<script>
    let { link } = $props();
</script>

<div class="hero p-40 mb-0">
    <div class="hero-content text-center">
        <div class="max-w-md">
            <h1 class="text-5xl font-bold">
                Cost estimations for solar projects
            </h1>
            <p class="py-6">
                Make your next project 20% more efficient with our platform
                solution.
            </p>
            <a type="button" class="btn btn-primary" href={link}>Learn more!</a>
        </div>
    </div>
</div>
