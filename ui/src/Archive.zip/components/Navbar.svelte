<header class="navbar bg-base-100 drop-shadow">
    <div class="flex-1 text-xl font-bold ml-6 mr-20">FINERGY</div>
    <nav class="flex-none">
        <ul class="menu menu-horizontal px-1">
            <li><a href="/">Home</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/contact">Contact</a></li>
        </ul>
    </nav>
</header>
