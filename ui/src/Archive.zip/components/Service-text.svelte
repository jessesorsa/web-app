<div class="hero mt-10 mb-10">
    <div class="hero-content flex-col lg:flex-row">
        <div class="max-w-md">
            <h1 class="text-7xl font-bold">Our Vision.</h1>
            <p class="py-9">
                At Finergy, we specialize in revolutionizing solar energy
                resource planning through our cutting-edge data platform. We
                provide precise cost forecasting, strategic planning, maximizing
                our clients solar potential.
            </p>
            <p class="py-0">
                Our innovative approach ensures efficient, sustainable, and
                cost-effective solar solutions, paving the way for a brighter,
                renewable future.
            </p>
        </div>
    </div>
</div>
