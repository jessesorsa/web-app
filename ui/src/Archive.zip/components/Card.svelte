<script>
    let { title, description, link } = $props();
</script>

<div class="card w-96 bg-base-100 shadow-xl mt-5 mb-5">
    <div class="card-body">
        <h2 class="card-title">{title}</h2>
        <p>{description}</p>
        <div class="card-actions justify-end">
            <a type="button" class="btn btn-primary" href={link}>More</a>
        </div>
    </div>
</div>
