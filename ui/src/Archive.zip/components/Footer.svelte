<footer class="footer p-10 bg-neutral text-neutral-content">
    <nav>
        <header class="footer-title">Finergy</header>
        <a href="/service" class="link link-hover">About us</a>
        <a href="/service" class="link link-hover">Contact</a>
        <a href="/service" class="link link-hover">Career at Finergy</a>
    </nav>
    <nav>
        <header class="footer-title">Services</header>
        <a href="/service" class="link link-hover">Resource planning</a>
        <a href="/service" class="link link-hover">Site optimization</a>
        <a href="/service" class="link link-hover">Project planning</a>
    </nav>
    <nav>
        <header class="footer-title">Legal</header>
        <a href="/service" class="link link-hover">Terms of use</a>
        <a href="/service" class="link link-hover">Privacy policy</a>
        <a href="/service" class="link link-hover">Cookie policy</a>
    </nav>
</footer>
